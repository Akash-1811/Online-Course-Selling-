from django.contrib import admin
from .models import Course,Tag,Prerequisite,Learning,Video,UserCourse,Payment

# Register your models here.

class TagAdmin(admin.TabularInline):
    model=Tag

class PrequisiteAdmin(admin.TabularInline):
    model=Prerequisite

class LearningAdmin(admin.TabularInline):
    model=Learning

class VideoAdmin(admin.TabularInline):
    model=Video

class CourseAdmin(admin.ModelAdmin):
    inlines=[TagAdmin,LearningAdmin,PrequisiteAdmin,VideoAdmin]
    list_display=['name','get_price','get_discount','active']

    def get_discount(self,course):
        return f"{course.discount} %" 
    def get_price(self,course):
        return f"₹ {course.price} " 
    get_discount.short_description='Discount'
    get_price.short_description='Price'

admin.site.register(Course,CourseAdmin)
admin.site.register(Video)
admin.site.register(UserCourse)
admin.site.register(Payment)


