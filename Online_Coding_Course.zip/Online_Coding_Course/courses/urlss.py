from http.client import HTTPResponse
from msilib.schema import Shortcut
from django.contrib import admin
from django.urls import path,include
from courses import views




urlpatterns = [
    path('',views.home , name='home'),
    path('course/<str:slug>',views.coursepage , name='coursepage'),
    path('signup',views.signup,name="signup"),
    path('login',views.login,name="login"),
    path('logout',views.signout,name='logout'),
    path('check-out/<str:slug>',views.checkout,name='check-out'),
    path('verify_payment',views.verifypayment,name='verify_payment'),
    path('my-courses',views.mycourses,name='my-courses')
    
]

