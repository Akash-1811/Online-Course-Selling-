from django.shortcuts import render,redirect
from django.shortcuts import HttpResponse
from .models import Course
from .models import Video
from django.contrib.auth.forms import UserCreationForm
from .register_forms import RegistrationForm
from .login_form import LoginForm
from django.contrib.auth import logout
from code_with_akash.settings import *
from time import time
from .models import Payment
from django.views.decorators.csrf import csrf_exempt
from .models import UserCourse
from django.contrib.auth.decorators import login_required



# Create your views here.

def home(request):
    courses=Course.objects.all()
    print(courses)
    return render(request,"courses/home.html",context={"courses":courses})


def coursepage(request,slug):
    #print(slug)
    course=Course.objects.get(slug=slug)
    serial_number=request.GET.get('lecture')
    videos=course.video_set.all().order_by("serial_number")
    if serial_number is None:
        serial_number=1
    video=Video.objects.get(serial_number=serial_number,course=course)
    if (video.is_preview is False):
        if (request.user.is_authenticated is False):
            return redirect("login")
        else:
            user=request.user
            try:

                user_course=UserCourse.objects.get(user=user,course=course)
            except:
                return redirect('check-out',slug=course.slug)

    print(video,"hi")
    context={"course":course,"video":video,"videos":videos}
    return render(request,"courses/course_page.html",context)


def signup(request):
    if request.method== "GET":
        form=RegistrationForm()
        return render(request,'courses/signup.html',context={'form':form})
    
    form=RegistrationForm(request.POST)
    if (form.is_valid()):
        user=form.save()
        if (user):
            return redirect("login")
    return render(request,'courses/signup.html',context={'form':form})


def login(request):
    if request.method=="GET":
        form=LoginForm()
        return render(request,'courses/login.html',context={'form':form})

    form=LoginForm(request=request, data=request.POST)
    if (form.is_valid()):
        return redirect('/')

    return render(request,'courses/login.html',context={'form':form})


def signout(request):
    logout(request)
    return redirect('/')



import razorpay
client=razorpay.Client(auth=(KEY_ID,KEY_SECRET))
@login_required(login_url='/login')
def checkout(request,slug):
    course=Course.objects.get(slug=slug)
    user=request.user
    action=request.GET.get('action')
    payment=None
    order=None
    error=None
    if action == 'create_payment':
        try:
            user_course=UserCourse.objects.get(user=user,course=course)
            error="You have already Enrolled"
        except:
            pass
        
        if error is None:
            amount=int((course.price-(course.price * course.discount * 0.01)) * 100)
            currency="INR"
            notes={"email":user.email,"name":f'{user.first_name} {user.last_name}'}
            reciept= f"codewithakash-{int(time())}"
            order=client.order.create({'receipt':reciept,'notes':notes,'amount':amount,'currency':currency})

            payment=Payment()
            payment.user=user
            payment.course=course
            payment.order_id=order.get('id')
            payment.save()

        


    return render(request,'courses/check_out.html',context={'course':course,'order':order,'payment':payment,'user':user,'error':error})


@csrf_exempt
def verifypayment(request):
    if request.method == "POST":
        data=request.POST
        context={}
        try:
            client.utility.verify_payment_signature(data)

            razorpay_order_id=data['razorpay_order_id']
            razorpay_payment_id=data['razorpay_payment_id']
            payment=Payment.objects.get(order_id=razorpay_order_id)
            payment.payment_id=razorpay_payment_id
            payment.status=True 
            
            userCourse=UserCourse(user=payment.user,course=payment.course)
            userCourse.save()

            payment.user_course=userCourse
            payment.save()
            return redirect('my-courses')
        except:
            return HttpResponse('Invalid Payment Details')
            


@login_required(login_url='login')
def mycourses(request):
    user=request.user
    user_course=UserCourse.objects.filter(user=user)
    context={
        'user_course':user_course
    }
    return render(request,'courses/my_courses.html',context=context)
           







